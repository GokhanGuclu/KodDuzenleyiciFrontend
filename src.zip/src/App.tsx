import './App.css'
import FileUpload from '@/components/FileUpload'

function App() {
  return (
    <div className="App">
      <FileUpload />
    </div>
  )
}

export default App
